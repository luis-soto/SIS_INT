Como testar se esta tudo funcionando:

- executar o VREP (versão 3.5rev4 ou superior - pode funcionar com qualquer versao 3.5rev1 em diante, mas nao eh garantido!).
(Obs: Testado apenas no Linux Ubuntu 64 bits(16.04). Nao funciona em ubuntu 14.04. Nao testei ainda em Ubuntu 18.04, ou outras distribuicoes linux).

- executar os programas "ProjetoRemoteApi/build/cppremoteapi" e "TesteBoostMemory/bin/Debug/TesteBoostMemory" em outros 2 terminais. Nao demorar muito entre a execucao de um e de outro, eles ficam se "procurando" por alguns segundos apenas e depois para a execucao(10 segundos aproximadamente).

- entrar comandos via teclado no programa "TesteBoostMemory". O comando 8 vai para frente, 6 vira a direita, 4 vira a esquerda.

- Nao esquecer de dar o "play" na cena antes de executar os codigos de controle.

- Nao eh necessario usar estes programas, nem a biblioteca boost, eles sao apenas exemplos de comando e acesso aos sensores do robo.

Joao Fabro
